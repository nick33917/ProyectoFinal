﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_compania.Modelo
{
    public class Compania
    {
        public int CodCompany { get; set; }
        public string Company { get; set; }
    }
}
