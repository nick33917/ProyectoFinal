﻿using AutoMapper;
using Base_de_Datos.DB;
using Microsoft.EntityFrameworkCore;
using ms_compania.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_compania.Negocio
{
    public class NegocioCompania : INegocioCompania
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public NegocioCompania(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public void BorrarCompania(int codCompania)
        {
            var result = _db.TblCompany.FirstOrDefault(c => c.CodCompany == codCompania);
            _db.TblCompany.Remove(result);
            _db.SaveChanges();
        }

        public void CrearCompania(Compania compania)
        {
            TblCompany companias = new TblCompany
            {
                CodCompany = compania.CodCompany,
                Company = compania.Company

            };

            _db.TblCompany.Add(companias);

            _db.SaveChanges();
         
        }

        public void ModificarCompania(int codCompania, Compania compania)
        {

            var result = _db.TblCompany.FirstOrDefault(c => c.CodCompany == codCompania);

            if (compania.Company != null)
            {
                result.Company = compania.Company;
            }

            _db.Entry(result).State = EntityState.Modified;
            _db.SaveChanges();
        }

        public Compania GetCompania(int codCompania)
        {
            return _mapper.Map<Compania>(_db.TblCompany.FirstOrDefault(c => c.CodCompany == codCompania));
        }

        public List<Compania> GetCompanias()
        {
            return _mapper.Map<List<Compania>>(_db.TblCompany.ToList());
        }
    }
}
