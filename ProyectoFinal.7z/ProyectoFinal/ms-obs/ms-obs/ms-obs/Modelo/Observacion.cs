﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;

namespace ms_obs.Modelo
{
    public class Observacion
    {
        public int CodObs { get; set; }
        public string Obs { get; set; }
    }
}
