﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ms_obs.Modelo;
using ms_obs.Negocio;

namespace ms_obs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ObsController : ControllerBase
    {
        private readonly IObs _negocioObs;

        public ObsController (IObs negocioObs) {
            _negocioObs = negocioObs;
        }
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Observacion>> Get()
        {
            return _negocioObs.GetObservaciones();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<Observacion> Get(int id)
        {
            return _negocioObs.GetObservacion(id);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] Observacion value)
        {
            _negocioObs.CrearObservacion(value);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Observacion value)
        {
            _negocioObs.ModificarObservacion(id, value);


        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _negocioObs.BorrarObservacion(id);
        }
    }
}
