﻿using ms_obs.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_obs.Negocio
{
    public interface IObs
    {
        List<Observacion> GetObservaciones();
        Observacion GetObservacion(int CodObs);
        void CrearObservacion(Observacion obs);
        void BorrarObservacion(int CodObs);
        void ModificarObservacion(int CodObs, Observacion obs);
    }
}
