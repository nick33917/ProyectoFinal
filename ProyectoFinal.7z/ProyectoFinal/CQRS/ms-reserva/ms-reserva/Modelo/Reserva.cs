﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;
namespace ms_reserva.Modelo
{
    public class Reserva
    {
        TblReservapublic virtual TblUsuarios IdUsuarioNavigation { get; set; }
        public virtual TblEstadoReserva EstadoReserva { get; set; }
        public virtual TblEstadoReserva EstadoNavigation { get; set; }
        public string AuthCode { get; set; }
        public int RangoHorarioId { get; set; }
        public long Asignacion { get; set; }
        public int EstadoReservaId { get; set; }
        public virtual TblRangoHorario RangoHorario { get; set; }
        public string MotivoRechazo { get; set; }
        public int TipoReserva { get; set; }
        public string Descripcion { get; set; }
        public int IdUsuario { get; set; }
        public DateTime FechaModificacion { get; set; }
        public DateTime FechaAlta { get; set; }
        public int Estado { get; set; }
        public long IdReserva { get; set; }
        public DateTime Fecha { get; set; }
        public virtual TblTipoReserva TipoReservaNavigation { get; set; }

    }
}
