﻿using ms_mail.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_mail.Negocio
{
    public interface INegocioMail
    {
        Task<List<UserMail>> GetMails();
        Task<UserMail> GetMail(int idMail);
        Task<bool> CrearMail(UserMail mail);
        Task<bool> ModificarMail(int idMail, UserMail mail);
        Task<bool> BorrarMail(int idMail);


    }
}
