﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;
using AutoMapper;
using MediatR;
using ms_mail.Modelo;
using Microsoft.EntityFrameworkCore;
using System.Threading;

namespace ms_mail.CQRS.Query
{
    public class GetMailsHandler : IRequestHandler<GetMailsQuery,List<UserMail>>
    {
        public readonly RRHHContext _db;
        public readonly IMapper _mapper;

        public GetMailsHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<List<UserMail>> Handle (GetMailsQuery request,CancellationToken cancellationToken )
        {
            return _mapper.Map<List<UserMail>>(await _db.TblUsuariosMail.ToListAsync());
        }
    }
}
