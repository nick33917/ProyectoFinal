﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_mail.Modelo;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using Base_de_Datos.DB;
using System.Threading;

namespace ms_mail.CQRS.Query
{
    public class GetMailHandler: IRequestHandler<GetMailQuery, UserMail>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetMailHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        
        public async Task<UserMail> Handle(GetMailQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<UserMail>(await _db.TblUsuariosMail.FirstOrDefaultAsync(c => c.IdMail == request.IdMail));

        }
    }
}
