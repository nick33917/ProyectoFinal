﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_mail.Modelo;

namespace ms_mail.CQRS.Command
{
    public class PostMailCommand: IRequest<bool>
    {
        public UserMail UnMail { get; set; }

    }
}

