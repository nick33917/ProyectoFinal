﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Base_de_Datos.DB;
using MediatR;
using ms_mail;
using System.Threading;

namespace ms_mail.CQRS.Command
{
    public class DeleteMailHandler : IRequestHandler <DeleteMailCommand,bool>
    {
        public readonly RRHHContext _db;

        public DeleteMailHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeleteMailCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblUsuariosMail.FirstOrDefault(c => c.IdMail ==request.IdMail);
                _db.TblUsuariosMail.Remove(result);

                await _db.SaveChangesAsync();
                rtn = true;


            }
            catch (Exception e)
            {
            }

            return rtn;

        }
    }
}
