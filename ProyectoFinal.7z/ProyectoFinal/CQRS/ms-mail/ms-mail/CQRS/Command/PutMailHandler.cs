﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_mail.Modelo;
using MediatR;
using Base_de_Datos.DB;
using Microsoft.EntityFrameworkCore;
using System.Threading;


namespace ms_mail.CQRS.Command
{
    public class PutMailHandler : IRequestHandler <PutMailCommand, bool>
    {
        public readonly RRHHContext _db;

        public PutMailHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(PutMailCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblUsuariosMail.FirstOrDefault(c => c.IdMail == request.IdMail);
                result.CodUsuario = request.unMail.CodUsuario;
                result.Mail = request.unMail.Mail;
                result.Tipo = request.unMail.Tipo;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rtn = true;
            }

            catch
            {
            }
            return rtn;
        }
    }
}
