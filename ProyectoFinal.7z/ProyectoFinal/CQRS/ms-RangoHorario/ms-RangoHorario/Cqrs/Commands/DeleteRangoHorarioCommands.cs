﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_RangoHorario.Cqrs.Commands
{
    public class DeleteRangoHorarioCommands : IRequest <bool>
    {
        public int Ranho { get; set; }
    }
}
