﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_RangoHorario.Cqrs.Commands
{
    public class PostRangoHorarioHandler : IRequestHandler<PostRangoHorarioCommands,bool>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostRangoHorarioHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PostRangoHorarioCommands request, CancellationToken cancellationToken)
        {
            try
            {
                var obj = _mapper.Map<TblRangoHorario>(request.UnRango);
                await _db.TblRangoHorario.AddRangeAsync(obj);
                await _db.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
