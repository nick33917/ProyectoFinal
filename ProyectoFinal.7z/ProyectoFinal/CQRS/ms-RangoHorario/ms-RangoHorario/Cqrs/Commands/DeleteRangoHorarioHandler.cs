﻿using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_RangoHorario.Cqrs.Commands
{
    public class DeleteRangoHorarioHandler : IRequestHandler<DeleteRangoHorarioCommands, bool>
    {
        private readonly RRHHContext _db;

        public DeleteRangoHorarioHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeleteRangoHorarioCommands request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblRangoHorario.FirstOrDefault(c => c.RangoHorarioId == request.Ranho);
                _db.TblRangoHorario.Remove(result);
                await _db.SaveChangesAsync();
                rtn = true;
            }
            catch
            {

            }
            return rtn;
        }
    }
}
