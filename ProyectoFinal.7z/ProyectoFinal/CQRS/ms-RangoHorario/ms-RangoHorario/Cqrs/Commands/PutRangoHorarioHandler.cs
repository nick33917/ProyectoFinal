﻿using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_RangoHorario.Cqrs.Commands
{
    public class PutRangoHorarioHandler : IRequestHandler<PutRangoHorarioCommands, bool>
    {
        public readonly RRHHContext _db;

        public PutRangoHorarioHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(PutRangoHorarioCommands request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblRangoHorario.FirstOrDefault(c => c.RangoHorarioId == request.Ranho);
                result.Descripcion = request.UnRango.Descripcion;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch
            {

            }
            return rtn;
        }
    }
}
