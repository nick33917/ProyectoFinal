﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_estado.Modelo;
using Base_de_Datos.DB;
using AutoMapper;
using MediatR;
using ms_estado.Cqrs.Querys;
using ms_estado.Cqrs.Commands;

namespace ms_estado.Negocio
{
    public class NegocioEstado : INegocioEstado
    {
        private readonly IMediator _mediator;
        public NegocioEstado(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<bool> BorrarEstado(int codEstado)
        {
            return await _mediator.Send(new DeleteEstadoCommand { codEstado = codEstado });
            
        }

        public async Task<bool> CrearEstado(Estado estado)
        {
            return await _mediator.Send(new PostEstadoCommand { UnEstado = estado });
            
        }

        public async Task<Estado> GetEstado(int codEstado)
        {
            return await _mediator.Send(new GetEstadoQuery {CodEstado = codEstado });   //return _mapper.Map<Estado>(_db.TblEstados.FirstOrDefault(c => c.CodEstado == codEstado));
        }

        public async Task<List<Estado>> GetEstados()
        {
            // return _mapper.Map<List<Estado>>(_db.TblEstados.ToList());
            return await _mediator.Send(new GetEstadosQuery());
        }

        public async Task<bool> ModificarEstado(int codEstado, Estado estado)
        {
            return await _mediator.Send(new PutEstadoCommand {codEstado = codEstado , unEstado = estado});
        }
    }
}
