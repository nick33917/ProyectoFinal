﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Base_de_Datos.DB;

namespace ms_estado.Cqrs.Commands
{
    public class DeleteEstadoHandler : IRequestHandler<DeleteEstadoCommand, bool>
    {
        public readonly RRHHContext _db;
        public DeleteEstadoHandler(RRHHContext db)
        {
            _db = db;
        }
        public async Task<bool> Handle(DeleteEstadoCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var result = _db.TblEstados.FirstOrDefault(c => c.CodEstado == request.codEstado);
                _db.TblEstados.Remove(result);
                await _db.SaveChangesAsync();
                rtn = true;
            }
            catch
            {

            }

            return rtn;
        }
    }
}
