﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_puesto.Modelo;
using MediatR;
using Base_de_Datos.DB;
using System.Threading;
using AutoMapper;

namespace ms_puesto.CQRS.Commands
{
    public class PostPuestoHandler : IRequestHandler<PostPuestoCommand, bool>
    {
        private readonly RRHHContext _db;

        public PostPuestoHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(PostPuestoCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                TblPuesto puesto = new TblPuesto
                {
                    NroPuesto = request.Puesto.NroPuesto,
                    NroBoca = request.Puesto.NroBoca,
                    Galcpu = request.Puesto.Galcpu,
                    Galmonitor = request.Puesto.Galmonitor,
                    Galtelefono = request.Puesto.Galtelefono,
                    InternoAcc = request.Puesto.InternoAcc,
                    CodInternoAccTitular = request.Puesto.CodInternoAccTitular,
                    InternoGalicia = request.Puesto.InternoGalicia,
                    CodInternoGaliciaTitular = request.Puesto.CodInternoGaliciaTitular,
                    Galcpuextra = request.Puesto.Galcpuextra

                };

                await _db.TblPuesto.AddAsync(puesto);
                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return rtn;

        }
    }
}

