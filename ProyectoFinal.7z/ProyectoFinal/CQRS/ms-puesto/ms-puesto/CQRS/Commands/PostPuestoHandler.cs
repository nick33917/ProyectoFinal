﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_puesto.Modelo;
using MediatR;
using Base_de_Datos.DB;
using System.Threading;
using AutoMapper;

namespace ms_puesto.CQRS.Commands
{
    public class PostPuestoHandler : IRequestHandler<PostPuestoQuery, bool>
    {
        private readonly RRHHContext _db;

        public PostPuestoHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(PostPuestoQuery request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                TblPuesto puesto = new TblPuesto
                {
                    NroPuesto = request.unPuesto.NroPuesto,
                    NroBoca = request.unPuesto.NroBoca,
                    Galcpu = request.unPuesto.Galcpu,
                    Galmonitor = request.unPuesto.Galmonitor,
                    Galtelefono = request.unPuesto.Galtelefono,
                    InternoAcc = request.unPuesto.InternoAcc,
                    CodInternoAccTitular = request.unPuesto.CodInternoAccTitular,
                    InternoGalicia = request.unPuesto.InternoGalicia,
                    CodInternoGaliciaTitular = request.unPuesto.CodInternoGaliciaTitular,
                    Galcpuextra = request.unPuesto.Galcpuextra

                };

                await _db.TblPuesto.AddAsync(puesto);
                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return rtn;

        }
    }
}

