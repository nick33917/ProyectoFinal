﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_puesto.Modelo;

namespace ms_puesto.CQRS.Commands
{
    public class PutPuestoHandler : IRequestHandler<PutPuestoCommand, bool>
    {
        
        private readonly RRHHContext _db;

        public PutPuestoHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(PutPuestoCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblPuesto.FirstOrDefault(c => c.NroPuesto == request.nroPuesto);
                result.CodUsuario = request.unPuesto.CodUsuario;
                result.NroPuesto = request.unPuesto.NroPuesto;
                result.NroBoca = request.unPuesto.NroBoca;
                result.Galcpu = request.unPuesto.Galcpu;
                result.Galmonitor = request.unPuesto.Galmonitor;
                result.Galtelefono = request.unPuesto.Galtelefono;
                result.InternoAcc = request.unPuesto.InternoAcc;
                result.CodInternoAccTitular = request.unPuesto.CodInternoAccTitular;
                result.InternoGalicia = request.unPuesto.InternoGalicia;
                result.CodInternoGaliciaTitular = request.unPuesto.CodInternoGaliciaTitular;
                result.Galcpuextra = request.unPuesto.Galcpuextra;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rtn = true;
            }
            catch (Exception)
            {

                throw;
            }

            return rtn;
        }
    }
}
