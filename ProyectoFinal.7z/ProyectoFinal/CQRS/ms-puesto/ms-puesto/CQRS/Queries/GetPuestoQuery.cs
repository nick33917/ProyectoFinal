﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_puesto.Modelo;

namespace ms_puesto.CQRS.Queries
{
    public class GetPuestoQuery : IRequest<Puesto>
    {
        public string NroPuesto { get; set; }
    }
}
