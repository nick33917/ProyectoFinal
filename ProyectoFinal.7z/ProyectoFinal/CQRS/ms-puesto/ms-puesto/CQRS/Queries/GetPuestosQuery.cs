﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_puesto.Modelo;

namespace ms_puesto.CQRS.Queries
{
    public class GetPuestosQuery : IRequest<List<Puesto>>
    {
    }
}
