﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;
using ms_puesto.Modelo;

namespace ms_puesto.Negocio
{
    public interface INegocioPuesto
    {
        Task<List<Puesto>> GetPuestos();
        Task<Puesto> GetPuesto(string NroPuesto);
        Task<bool> CrearPuesto(Puesto puesto);
        Task<bool> BorrarPuesto(string NroPuesto);
        Task<bool> ModificarPuesto(string NroPuesto, Puesto puesto);
    }
}
