﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_puesto.Modelo;
using MediatR;
using ms_puesto.CQRS.Commands;
using ms_puesto.CQRS.Queries;

namespace ms_puesto.Negocio
{
    public class NegocioPuesto : INegocioPuesto
    {
        private readonly IMediator _mediatr;

        public NegocioPuesto(IMediator mediatr)
        {
            _mediatr = mediatr;
        }

        public async Task<bool> BorrarPuesto(string codPuesto)
        {
            return await _mediatr.Send(new DeletePuestoCommand { });
        }

        public async Task<bool> CrearPuesto(Puesto puesto)
        {
           return await _mediatr.Send(new PostPuestoQuery { unPuesto = puesto });
        }

        public async Task<Puesto> GetPuesto(string nroPuesto)
        {
            return await _mediatr.Send(new GetPuestoQuery{NroPuesto = nroPuesto});
        }

        public async Task<List<Puesto>> GetPuestos()
        {
             return await _mediatr.Send(new GetPuestosQuery());
        }

        public async Task<bool> ModificarPuesto(string codPuesto, Puesto puesto)
        {
            return await _mediatr.Send(new PutPuestoCommand {  nroPuesto = codPuesto, unPuesto = puesto });
        }
    }
}
