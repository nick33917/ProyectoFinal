﻿using AutoMapper;
using Base_de_Datos.DB;
using ms_TipoReservaNavigation.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_TipoReservaNavigation
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Add as many of these lines as you need to map your objects
            CreateMap<TipoReservaNavigation, TblTipoReserva>();
            CreateMap<TblTipoReserva, TipoReservaNavigation>();
        }
    }   
}
