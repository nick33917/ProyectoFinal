﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using MediatR;
using ms_TipoReservaNavigation.Modelo;

namespace ms_TipoReservaNavegation.CQRS.Query
{
    public class GetUnTipoReservaNavigationQuery : IRequest<TipoReservaNavigation>
    {
        public int TipoReservaId { get; set; }
    }
}
