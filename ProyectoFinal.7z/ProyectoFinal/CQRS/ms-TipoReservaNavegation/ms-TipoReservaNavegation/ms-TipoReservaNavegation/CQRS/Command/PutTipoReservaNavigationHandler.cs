﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Threading;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_TipoReservaNavigation.Modelo;


namespace ms_TipoReservaNavegation.CQRS.Command
{
    public class PutTipoReservaNavigationHandler : IRequestHandler <PutTipoReservaNavigationCommand, bool>
    {
        private readonly RRHHContext _db;

        public PutTipoReservaNavigationHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(PutTipoReservaNavigationCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblTipoReserva.FirstOrDefault(c => c.TipoReservaId == request.TipoReservaId);

               
                result.Descripcion = request.unTipoReservaNavigation.Descripcion;
                result.DescripcionCorta = request.unTipoReservaNavigation.DescripcionCorta;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch (Exception)
            {
     
            }

            return rtn;

        }
    }
}
