﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using MediatR;


namespace ms_TipoReservaNavegation.CQRS.Command
{
    public class DeleteTipoReservaNavigationCommand : IRequest <bool>
    {
        public int TipoReservaId { get; set; }
    }
}
