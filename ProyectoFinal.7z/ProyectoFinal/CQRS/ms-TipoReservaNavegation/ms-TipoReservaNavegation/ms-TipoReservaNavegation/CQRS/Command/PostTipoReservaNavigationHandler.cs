﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Base_de_Datos.DB;
using AutoMapper;
using MediatR;
using System.Threading;

namespace ms_TipoReservaNavegation.CQRS.Command
{
    public class PostTipoReservaNavigationHandler : IRequestHandler<PostTipoReservaNavigationCommand,bool>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostTipoReservaNavigationHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PostTipoReservaNavigationCommand request, CancellationToken cancellationToken)
        {
            try
            {
                TblTipoReserva tblTipoReservaNavigation = new TblTipoReserva
                {
                    TipoReservaId = request.UnTipoReservaNavigation.TipoReservaId,
                    Descripcion = request.UnTipoReservaNavigation.Descripcion,
                    DescripcionCorta = request.UnTipoReservaNavigation.DescripcionCorta
                };

                await _db.TblTipoReserva.AddAsync(tblTipoReservaNavigation);
                await _db.SaveChangesAsync();
                return true;

            }
            catch 
            {

                return false;
            }

        }

    }
}
