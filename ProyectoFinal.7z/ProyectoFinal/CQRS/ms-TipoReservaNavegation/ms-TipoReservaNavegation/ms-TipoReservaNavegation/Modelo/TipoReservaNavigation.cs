﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;

namespace ms_TipoReservaNavigation.Modelo
{
    public class TipoReservaNavigation
    {
        public int TipoReservaId { get; set; }
        public string Descripcion { get; set; }
        public string DescripcionCorta { get; set; }
       
    }
}
