﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;
using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using ms_TipoReservaNavigation.Modelo;
using ms_TipoReservaNavegation.CQRS.Query;
using ms_TipoReservaNavegation.CQRS.Command;

namespace ms_TipoReservaNavigation.Negocio
{
    public class NegocioTipoReservaNavigation : INegocioTipoReservaNavigation
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;
        private readonly IMediator _mediatr;

        public NegocioTipoReservaNavigation(RRHHContext db, IMapper mapper, IMediator mediatr)
        {
            _db = db;
            _mapper = mapper;
            _mediatr = mediatr;
        }

        //GET ALL
        public async Task<List<TipoReservaNavigation>> GetTipoReservaNavigation()
        {
            return await _mediatr.Send(new GetAllTipoReservaNavigationQuery());

        }

        //GET ID
        public async Task<TipoReservaNavigation> GetUnTipoReservaNavigation(int TipoReservaId)
        {
            return await _mediatr.Send(new GetUnTipoReservaNavigationQuery { TipoReservaId = TipoReservaId });
        }

       //POST - CREAR
        public async Task<bool> CrearTipoReservaNavigation(TipoReservaNavigation tipoReservaNavigation)
        {
            return await _mediatr.Send(new PostTipoReservaNavigationCommand { UnTipoReservaNavigation = tipoReservaNavigation });
        }

        //PUT- MODIFICAR
        public async Task<bool> ModificarTipoReservaNavigation(int TipoReservaId, TipoReservaNavigation tipoReservaNavigation)
        {
            return await _mediatr.Send(new PutTipoReservaNavigationCommand { TipoReservaId = TipoReservaId, unTipoReservaNavigation = tipoReservaNavigation });
        }

        // DELETE
        public async Task<bool> BorrarTipoReservaNavigation(int TipoReservaId)
        {
            return await _mediatr.Send(new DeleteTipoReservaNavigationCommand { TipoReservaId = TipoReservaId });
        }

    }  
    
}
