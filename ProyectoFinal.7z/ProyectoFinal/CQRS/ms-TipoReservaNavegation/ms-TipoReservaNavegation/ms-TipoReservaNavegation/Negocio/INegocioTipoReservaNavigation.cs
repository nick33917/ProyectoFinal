﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_TipoReservaNavigation.Modelo;

namespace ms_TipoReservaNavigation.Negocio
{
    public interface INegocioTipoReservaNavigation
    {
        Task<List<TipoReservaNavigation>> GetTipoReservaNavigation();
        Task<TipoReservaNavigation> GetUnTipoReservaNavigation(int TipoReservaId);
        Task<bool> CrearTipoReservaNavigation(TipoReservaNavigation tipoReservaNavigation);
        Task<bool> ModificarTipoReservaNavigation(int TipoReservaId, TipoReservaNavigation tipoReservaNavigation);
        Task<bool> BorrarTipoReservaNavigation(int TipoReservaId);

    }
}
