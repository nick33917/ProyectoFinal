﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_usuario.Modelo;
using ms_usuario.Cqrs.Queries;
using ms_usuario.Cqrs.Commands;

namespace ms_usuario.Negocio
{
    public class NegocioUsuario : INegocioUsuario
    {
        private readonly IMediator _mediatr;

        public NegocioUsuario(IMediator mediatr)
        {
            _mediatr = mediatr;
        }

        public async Task<bool> BorrarUsuario(int CodUsuario)
        {
            return await _mediatr.Send(new DeleteUsuarioCommand { CodUsusario = CodUsuario });
        }

        public async Task<bool> CrearUsuario(Usuario usuario)
        {
            return await _mediatr.Send(new PostUsuarioCommand { usuario = usuario });
        }

        public async Task<Usuario> GetUsuario(int CodUsuario)
        {
            return await _mediatr.Send(new GetUsuarioQuery { CodUsuario = CodUsuario });
        }

        public async Task<List<Usuario>> GetUsuarios()
        {
            return await _mediatr.Send(new GetUsuariosQuery());
        }

        public async Task<bool> ModificarUsuario(int CodUsuario, Usuario usuario)
        {
            return await _mediatr.Send(new PutUsuarioCommand { CodUser = CodUsuario, User = usuario });
        }
    }
}
