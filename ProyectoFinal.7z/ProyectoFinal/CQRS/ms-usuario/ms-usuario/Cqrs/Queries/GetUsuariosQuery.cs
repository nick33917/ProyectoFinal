﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_usuario.Modelo;


namespace ms_usuario.Cqrs.Queries
{
    public class GetUsuariosQuery : IRequest<List<Usuario>>
    {
    }
}
