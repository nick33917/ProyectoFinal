﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_usuario.Cqrs.Commands
{
    public class PostUsuarioHandler : IRequestHandler<PostUsuarioCommand, bool>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostUsuarioHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PostUsuarioCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var objTbl = _mapper.Map<TblUsuarios>(request.usuario);
                await _db.TblUsuarios.AddAsync(objTbl);
                await _db.SaveChangesAsync();
                return true;
            }
            catch
            {
                rtn = false;
            }
            return rtn;
           
        }
    }
}
