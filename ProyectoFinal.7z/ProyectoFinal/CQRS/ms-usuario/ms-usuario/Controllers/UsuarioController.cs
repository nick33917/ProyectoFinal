﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ms_usuario.Negocio;
using ms_usuario.Modelo;

namespace ms_usuario.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        private readonly INegocioUsuario _negocioUsuario;

        public ValuesController(INegocioUsuario negocioUsuario)
        {
            _negocioUsuario = negocioUsuario;
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<List<Usuario>>> Get()
        {
            return await _negocioUsuario.GetUsuarios();
        }

        // GET api/values/5
        [HttpGet("{codUser}")]
        public async Task<ActionResult<Usuario>> Get(int codUser)
        {
            return await _negocioUsuario.GetUsuario(codUser);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool> Post([FromBody] Usuario value)
        {
            return await _negocioUsuario.CrearUsuario(value);
        }

        // PUT api/values/5
        [HttpPut("{codUser}")]
        public async Task<bool>Put(int codUser, [FromBody] Usuario value)
        {
            return await _negocioUsuario.ModificarUsuario(codUser, value);
        }

        // DELETE api/values/5
        [HttpDelete("{codUser}")]
        public async Task<bool> Delete(int codUser)
        {
            return await _negocioUsuario.BorrarUsuario(codUser);
        }
    }
}
