﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ms_EstadoReserva.Modelo;
using ms_EstadoReserva.Negocio;

namespace ms_EstadoReserva.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstadoReservaController : ControllerBase
    {
        private readonly INegocioEstadoReserva _NegocioEstadoReserva;

        public EstadoReservaController(INegocioEstadoReserva NegocioEstadoReserva)
        {
            _NegocioEstadoReserva = NegocioEstadoReserva;
        }


        // GET api/values
        [HttpGet]
        public async Task<ActionResult<List<Estadoreserva>>> Get()
        {
            return await _NegocioEstadoReserva.GetEstadosReservas();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Estadoreserva>> Get(int id)
        {
            return await _NegocioEstadoReserva.GetEstadoreserva(id);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool> Post([FromBody] Estadoreserva UnEsReva)
        {
            bool x = await _NegocioEstadoReserva.CrearEstadoReserva(UnEsReva);
            return x;

        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public async Task <bool> Put(int id, [FromBody] Estadoreserva UnEsReva)
        {
            return await _NegocioEstadoReserva.ModificarEstadoReserva(id, UnEsReva);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<bool>Delete(int id)
        {
            return await _NegocioEstadoReserva.BorrarEstadoReserva(id);
        }
    }
}
