﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Base_de_Datos.DB;
using ms_EstadoReserva.Modelo;

namespace ms_EstadoReserva.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Estadoreserva, TblEstadoReserva>();
            CreateMap<TblEstadoReserva, Estadoreserva>();
        }

    }
}