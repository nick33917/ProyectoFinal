﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_EstadoReserva.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Cqrs.Querys
{
    public class GetEstadoReservaHandler : IRequestHandler<GetEstadoReservaQuery, Estadoreserva>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetEstadoReservaHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<Estadoreserva> Handle(GetEstadoReservaQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<Estadoreserva>(await _db.TblEstadoReserva.FirstOrDefaultAsync(c => c.EstadoReservaId == request.CodEsResv));
        }
    }
}
