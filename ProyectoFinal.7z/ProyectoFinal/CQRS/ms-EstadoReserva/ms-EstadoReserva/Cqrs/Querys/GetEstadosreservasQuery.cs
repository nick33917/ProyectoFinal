﻿using MediatR;
using ms_EstadoReserva.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Cqrs.Querys
{
    public class GetEstadosreservasQuery : IRequest<List<Estadoreserva>>
    {
    }
}
