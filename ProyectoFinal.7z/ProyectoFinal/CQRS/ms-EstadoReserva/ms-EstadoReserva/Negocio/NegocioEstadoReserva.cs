﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_EstadoReserva.Cqrs.Commands;
using ms_EstadoReserva.Cqrs.Querys;
using ms_EstadoReserva.Modelo;

namespace ms_EstadoReserva.Negocio
{
    public class NegocioEstadoReserva : INegocioEstadoReserva
    {
        private readonly IMediator _mediator;

        public NegocioEstadoReserva(IMediator mediator)
        {
            _mediator = mediator;
        }


        public async Task<bool> BorrarEstadoReserva(int EstadoreservaId)
        {
            return await _mediator.Send(new DeleteEstadoReservaCommands { EstadoreservaId = EstadoreservaId });
        }

        public async Task<bool> CrearEstadoReserva(Estadoreserva UnEsReva)
        {
            return await _mediator.Send(new PostEstadoReservaCommands {UnEstadoReserva = UnEsReva });
        }

        public async Task<Estadoreserva> GetEstadoreserva(int CodEsResv)
        {
            return await _mediator.Send(new GetEstadoReservaQuery { CodEsResv = CodEsResv });
        }

        public async Task<List<Estadoreserva>> GetEstadosReservas()
        {
            return await _mediator.Send(new GetEstadosreservasQuery());
        }

        public async Task<bool> ModificarEstadoReserva(int EstadoreservaId, Estadoreserva UnEsReva)
        {
            return await _mediator.Send(new PutEstadosReservaCommands { EstadoreservaId = EstadoreservaId, UnEstadoReserva = UnEsReva });
        }
    }
}
