﻿using ms_EstadoReserva.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Negocio
{
    public interface INegocioEstadoReserva
    {
        Task<List<Estadoreserva>> GetEstadosReservas();
        Task<Estadoreserva> GetEstadoreserva(int CodEsResv);
        Task<bool> CrearEstadoReserva(Estadoreserva UnEsReva);
        Task<bool> BorrarEstadoReserva(int EstadoreservaId);
        Task<bool> ModificarEstadoReserva(int EstadoreservaId, Estadoreserva UnEsReva);
    }
}
