﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ms_telefono.Modelo;
using ms_telefono.Negocio;

namespace ms_telefono.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TelefonoController : ControllerBase
    {
        private readonly INegocioTelefono _NegocioTelefono;

        public TelefonoController(INegocioTelefono NegocioTelefono)
        {
            _NegocioTelefono = NegocioTelefono;
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<List<Telefono>>> Get()
        {
            return await _NegocioTelefono.GetTelefonos();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Telefono>> Get(int id)
        {
            return await _NegocioTelefono.GetTelefono(id);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool> Post([FromBody] Telefono telefono)
        {
            bool x = await _NegocioTelefono.CrearTelefono(telefono);
            return x;
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public async Task<bool> Put(int id, [FromBody] Telefono telefono)
        {
            return await _NegocioTelefono.ModificarTelefono(id,telefono);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<bool>Delete(int id)
        {
            return await _NegocioTelefono.BorrarTelefono(id);
        }
    }
}
