﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using ms_telefono.Modelo;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ms_telefono.Cqrs.Querys
{
    public class GetTelefonoHandler : IRequestHandler<GetTelefonoQuery, Telefono>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetTelefonoHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<Telefono> Handle(GetTelefonoQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<Telefono>(await _db.TblUsuariosTelefono.FirstOrDefaultAsync(c => c.IdTel == request.IdTel));
        }
    }
}
