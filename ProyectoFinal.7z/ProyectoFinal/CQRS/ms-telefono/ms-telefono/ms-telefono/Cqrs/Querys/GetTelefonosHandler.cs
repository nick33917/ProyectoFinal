﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_telefono.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_telefono.Cqrs.Querys
{
    public class GetTelefonosHandler : IRequestHandler<GetTelefonosQuery, List<Telefono>>
    {
        public readonly RRHHContext _db;
        public readonly IMapper _mapper;

        public GetTelefonosHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<List<Telefono>> Handle(GetTelefonosQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<Telefono>>(await _db.TblUsuariosTelefono.ToListAsync());
        }
    }
}
