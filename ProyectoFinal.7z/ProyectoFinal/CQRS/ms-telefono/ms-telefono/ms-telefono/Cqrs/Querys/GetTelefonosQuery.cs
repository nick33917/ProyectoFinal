﻿using MediatR;
using ms_telefono.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_telefono.Cqrs.Querys
{
    public class GetTelefonosQuery : IRequest<List<Telefono>>
    {
    }
}
