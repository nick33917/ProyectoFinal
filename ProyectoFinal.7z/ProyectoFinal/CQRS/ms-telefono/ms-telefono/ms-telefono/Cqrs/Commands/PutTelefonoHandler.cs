﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_telefono.Cqrs.Commands
{
    public class PutTelefonoHandler : IRequestHandler<PutTelefonoCommands, bool>
    {
        private readonly RRHHContext _db;

        public PutTelefonoHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
        }

        public async Task<bool> Handle(PutTelefonoCommands request, CancellationToken cancellationToken)
        {
            bool rst = false;
            try
            {
                var result = _db.TblUsuariosTelefono.FirstOrDefault(c => c.IdTel == request.PostIdTel);

                result.CodUsuario = request.unTelefono.CodUsuario;
                result.Numero = request.unTelefono.Numero;
                result.Tipo = request.unTelefono.Tipo;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rst = true;
                Console.WriteLine(rst);
            }
            catch
            {
             
                Console.WriteLine(rst);
            }
            return rst;
        }
    }
}
