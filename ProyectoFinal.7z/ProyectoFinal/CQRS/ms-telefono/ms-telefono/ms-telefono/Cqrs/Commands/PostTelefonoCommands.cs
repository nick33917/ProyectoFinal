﻿using MediatR;
using ms_telefono.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_telefono.Cqrs.Commands
{
    public class PostTelefonoQuery : IRequest<bool>
    {
        public Telefono  UnTelefono { get; set; }

        
    }
}
