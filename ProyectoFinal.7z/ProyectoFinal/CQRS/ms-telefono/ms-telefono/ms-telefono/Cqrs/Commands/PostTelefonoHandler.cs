﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_telefono.Cqrs.Commands
{
    public class PostTelefonoHandler : IRequestHandler<PostTelefonoQuery, bool>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostTelefonoHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PostTelefonoQuery request, CancellationToken cancellationToken)
        {
            try
            {
                TblUsuariosTelefono tblTelefono = new TblUsuariosTelefono 
                {
                    CodUsuario = request.UnTelefono.CodUsuario,
                    Numero = request.UnTelefono.Numero,
                    Tipo = request.UnTelefono.Tipo,
                    IdTel = request.UnTelefono.IdTel

                };
                await _db.TblUsuariosTelefono.AddAsync(tblTelefono);
                await _db.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

    }
}
