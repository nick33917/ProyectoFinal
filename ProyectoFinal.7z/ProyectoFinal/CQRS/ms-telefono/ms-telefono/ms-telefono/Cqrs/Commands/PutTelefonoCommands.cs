﻿using MediatR;
using ms_telefono.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_telefono.Cqrs.Commands
{
    public class PutTelefonoCommands : IRequest<bool>
    {
        public Telefono unTelefono { get; set; }
        public int PostIdTel { get; set; }
    }
}
