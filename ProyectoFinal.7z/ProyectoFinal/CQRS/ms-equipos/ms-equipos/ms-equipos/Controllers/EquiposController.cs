﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Base_de_Datos.DB;
using ms_equipos.Negocio;
using ms_equipos.Modelo;

namespace ms_equipos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EquiposController : ControllerBase
    {
        private readonly INegocioEquipo _negocioEquipo;

        public EquiposController(INegocioEquipo negocioEquipo)
        {
            _negocioEquipo = negocioEquipo;
        }



        // GET api/values
        [HttpGet]
        public async Task<ActionResult<List<Equipo>>> Get()
        {
            return await _negocioEquipo.GetEquipos();
          
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task <ActionResult<Equipo>> Get(int id)
        {
            return await _negocioEquipo.GetEquipo(id);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool>Post([FromBody] Equipo value)
        {
            return await _negocioEquipo.CrearEquipo(value);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public async Task<bool> Put(int id, [FromBody] Equipo value)
        {
            return await _negocioEquipo.ModificarEquipo(id, value);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<bool>Delete(int id)
        {
            return await _negocioEquipo.BorrarEquipo(id);
        }
    }
}
