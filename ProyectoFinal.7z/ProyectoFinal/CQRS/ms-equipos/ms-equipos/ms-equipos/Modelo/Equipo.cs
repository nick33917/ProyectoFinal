﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_equipos.Modelo
{
    public class Equipo
    {
        public int CodGrupo { get; set; }
        public string NombreGrupo { get; set; }
        public int? Planifica { get; set; }

    }
}
