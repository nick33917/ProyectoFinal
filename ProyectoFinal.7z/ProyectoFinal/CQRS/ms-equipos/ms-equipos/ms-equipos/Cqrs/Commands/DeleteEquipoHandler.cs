﻿using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ms_equipos;


namespace ms_equipos.Cqrs.commands
{
    public class DeleteEquipoHandler : IRequestHandler<DeleteEquipoCommand,bool>
    {

        public readonly RRHHContext _db;

        public DeleteEquipoHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeleteEquipoCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var result = _db.TblGrupos.FirstOrDefault(c => c.CodGrupo == request.codGrupo);
                _db.TblGrupos.Remove(result);

                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch
            {

            }
            return rtn;

        }
    }
}
