﻿using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Base_de_Datos;
using Microsoft.EntityFrameworkCore;

namespace ms_equipos.Cqrs.commands
{
    public class PutEquipohandler : IRequestHandler<PutEquipoCommand, bool>
    {
        private readonly RRHHContext _db;

        public PutEquipohandler(RRHHContext db)
        {
            _db = db;
        }
        public async Task<bool> Handle(PutEquipoCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            { 
                var result = _db.TblGrupos.FirstOrDefault(c => c.CodGrupo == request.CodGrupo);
                result.NombreGrupo = request.grupo.NombreGrupo;
                result.Planifica = request.grupo.Planifica;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch
            {

            }
            return rtn;
        }
    }
}
