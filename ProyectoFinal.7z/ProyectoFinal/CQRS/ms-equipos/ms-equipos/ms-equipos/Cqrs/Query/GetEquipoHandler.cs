﻿using MediatR;
using ms_equipos.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Base_de_Datos;
using Base_de_Datos.DB;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

namespace ms_equipos.Cqrs.Query
{
    public class GetEquipoHandler : IRequestHandler<GetEquipoQuery, Equipo>
    {

        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetEquipoHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<Equipo> Handle(GetEquipoQuery request, CancellationToken cancellationToken)
        {
            return  _mapper.Map<Equipo>(await _db.TblGrupos.FirstOrDefaultAsync(c => c.CodGrupo == request.CodGrupo));
        }
    }
}
