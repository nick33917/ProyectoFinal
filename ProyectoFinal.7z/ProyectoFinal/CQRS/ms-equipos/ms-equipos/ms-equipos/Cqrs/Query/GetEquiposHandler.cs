﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_equipos.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_equipos.Cqrs.Query
{
    public class GetEquiposHandler : IRequestHandler<GetEquiposQuery, List<Equipo>>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetEquiposHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

     
        public async Task<List<Equipo>> Handle(GetEquiposQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<Equipo>>(await _db.TblGrupos.ToListAsync());
        }
    }
}
