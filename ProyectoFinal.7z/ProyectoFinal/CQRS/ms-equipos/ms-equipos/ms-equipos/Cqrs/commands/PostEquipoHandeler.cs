﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_equipos.Cqrs.commands
{
    public class PostEquipoHandeler : IRequestHandler<PostEquipoQuery, bool>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostEquipoHandeler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PostEquipoQuery request, CancellationToken cancellationToken)
        {
            try
            {
                TblGrupos tblGrupos = new TblGrupos
                {
                    NombreGrupo = request.grupo.NombreGrupo,
                    Planifica = request.grupo.Planifica
                };
                await _db.TblGrupos.AddAsync(tblGrupos);
                await _db.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
