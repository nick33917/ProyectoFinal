﻿using MediatR;
using ms_equipos.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_equipos.Cqrs.commands
{
    public class PostEquipoQuery : IRequest<bool>
    {
        public Equipo grupo { get; set; }
    }
}
