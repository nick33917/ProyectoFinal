﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_evaluacion.Modelo;

namespace ms_evaluacion.CQRS.Queries
{
    public class GetEvaluacionesHandler : IRequestHandler<GetEvaluacionesQuery, List<Evaluacion>>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetEvaluacionesHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<List<Evaluacion>> Handle(GetEvaluacionesQuery request, CancellationToken cancellationToken)
        {

           // var infoTabla = await _db.TblEvaluacion.ToListAsync();
          return _mapper.Map<List<Evaluacion>>(await _db.TblEvaluacion.ToListAsync());
            
        }
    }
}
