﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_evaluacion.Modelo;

namespace ms_evaluacion.CQRS.Queries
{
    public class GetEvaluacionQuery : IRequest<Evaluacion>
    {
        public int MyProperty { get; set; }
    }
}
