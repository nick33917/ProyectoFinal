﻿using MediatR;
using ms_evaluacion.CQRS.Queries;
using ms_evaluacion.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_evaluacion.Negocio
{
    public class NegocioEvaluacion : INegocioEvaluacion
    {
        private readonly IMediator _mediatr;

        public NegocioEvaluacion(IMediator mediatr)
        {
            _mediatr = mediatr;
        }

        public Task<bool> BorrarEvaluacion(int IdItemEvaluacion)
        {
            throw new NotImplementedException();
        }

        public Task<bool> CrearEvaluacion(Evaluacion evaluacion)
        {
            throw new NotImplementedException();
        }

        public Task<Evaluacion> GetEvaluacion(int IdItemEvaluacion)
        {
            throw new NotImplementedException();
        }

        public async Task<List<Evaluacion>> GetEvaluaciones()
        {
            return await _mediatr.Send(new GetEvaluacionesQuery());
        }

        public Task<bool> ModificarEvaluacion(int IdItemEvaluacion, Evaluacion evaluacion)
        {
            throw new NotImplementedException();
        }
    }
}
