﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;

namespace ms_evaluacion.Modelo
{
    public class Evaluacion
    {
        public int IdItemEvaluacion { get; set; }
        public int CodUsuario { get; set; }
        public int CodUsuarioAlta { get; set; }
        public string Comentario { get; set; }
        public int AnioFiscal { get; set; }
        public DateTime? FechaAlta { get; set; }
        public string Ranking { get; set; }


    }
}
