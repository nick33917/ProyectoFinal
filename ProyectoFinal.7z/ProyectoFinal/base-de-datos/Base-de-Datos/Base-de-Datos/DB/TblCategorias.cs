﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblCategorias
    {
        public TblCategorias()
        {
            TblUsuarios = new HashSet<TblUsuarios>();
        }

        public int CodCategoria { get; set; }
        public string NombreCategoria { get; set; }
        public string Level { get; set; }
        public string Skill { get; set; }

        public virtual ICollection<TblUsuarios> TblUsuarios { get; set; }
    }
}
