﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblDetalleHorasGop
    {
        public int CodDetalle { get; set; }
        public int? CodUsuario { get; set; }
        public int? Codperiodo { get; set; }
        public int? Año { get; set; }
        public int? Codgrupo { get; set; }
        public int? Codacuerdo { get; set; }
        public int? CodSemana { get; set; }
        public int? CodOportunidad { get; set; }
        public decimal? Incurrido { get; set; }
    }
}
