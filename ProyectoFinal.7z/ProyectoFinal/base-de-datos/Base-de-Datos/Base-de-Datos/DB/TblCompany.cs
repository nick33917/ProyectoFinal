﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblCompany
    {
        public int CodCompany { get; set; }
        public string Company { get; set; }
    }
}
