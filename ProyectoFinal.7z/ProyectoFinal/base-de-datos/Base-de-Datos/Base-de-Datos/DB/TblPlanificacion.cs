﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblPlanificacion
    {
        public int CodPlanificacion { get; set; }
        public int CodPeriodo { get; set; }
        public int Anio { get; set; }
        public int? CodAcuerdo { get; set; }
        public int? CodGrupo { get; set; }
        public int? NumGalar { get; set; }
        public int? CodTipoGalar { get; set; }
        public int? CodEstado { get; set; }
        public int? Prioridad { get; set; }
        public decimal? EstHoras { get; set; }
        public DateTime? EstFechaAdp { get; set; }
        public DateTime? EstFechaInicio { get; set; }
        public DateTime? EstFechaFin { get; set; }
        public decimal? DesaHoras { get; set; }
        public DateTime? DesaFechaInicio { get; set; }
        public DateTime? DesaFechaInte { get; set; }
        public DateTime? DesaFechaHomo { get; set; }
        public DateTime? DesaFechaPiloto { get; set; }
        public DateTime? DesaFechaProd { get; set; }
        public DateTime? DesaFechaFin { get; set; }
        public decimal? SeguiHorasAcuerdoGalarInicial { get; set; }
        public decimal? SeguiHorasAcuerdoGalarComprometidas { get; set; }
        public decimal? SeguiHorasAcuerdoGalarActual { get; set; }
        public decimal? SeguiHorasIncurridasTotales { get; set; }
        public decimal? SeguiHorasIncurridasGalar { get; set; }
        public decimal? SeguiHorasIncurridasGalarEst { get; set; }
        public DateTime? SeguiFechaFinGalarActual { get; set; }
        public DateTime? SeguiFechaFinGalarComprometida { get; set; }
        public DateTime? SeguiFechaFinGalarReal { get; set; }
        public string Comentarios { get; set; }
        public int? NumProblem { get; set; }
        public int? Responsable1 { get; set; }
        public int? Responsable2 { get; set; }
        public int? Evolutivo { get; set; }
        public int? Finalizado { get; set; }
        public DateTime? FechaUltimaModificacion { get; set; }
        public int? CodUsuarioUltimaModificacion { get; set; }
        public string SeguiEstadoAcuerdo { get; set; }
        public int? Soporte { get; set; }
        public int? CodOportunidad { get; set; }
        public decimal? HorasSolicitadasOpp { get; set; }
        public string ComentariosOpp { get; set; }
        public DateTime? Inicio { get; set; }
        public DateTime? Fin { get; set; }
        public int? Avance { get; set; }
        public int? NovedadOpp { get; set; }
        public DateTime? FechaUltimaModificacionGop { get; set; }
        public int? CodGrupoGop { get; set; }
        public double? EstHorasTotales { get; set; }
        public int? CheckPeerReview { get; set; }
        public int? UserControlPeerReview { get; set; }
        public DateTime? FechaRealImplementacion { get; set; }
        public decimal? TotalPlanificadas { get; set; }
        public decimal? IncurridoAcumulado { get; set; }
        public decimal? DesvioMensual { get; set; }
        public decimal? DesvioAcumulado { get; set; }
        public string DescripcionOportunidad { get; set; }
        public string LinkPeerReview { get; set; }
    }
}
