﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblEstadosPeerReview
    {
        public TblEstadosPeerReview()
        {
            TblPeerReview = new HashSet<TblPeerReview>();
        }

        public string CodEstadoPeer { get; set; }
        public string DescripcionPeer { get; set; }

        public virtual ICollection<TblPeerReview> TblPeerReview { get; set; }
    }
}
