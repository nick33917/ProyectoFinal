﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRiesgos
    {
        public int NumGalar { get; set; }
        public string CodAcuerdo { get; set; }
        public short CodSeveridad { get; set; }
        public short CodOcurrencia { get; set; }
        public string AccionesMitigacion { get; set; }
        public string AccionesContingencia { get; set; }
        public string DetalleRiesgo { get; set; }

        public virtual TblRiesgoOcurrencia CodOcurrenciaNavigation { get; set; }
        public virtual TblRiesgoSeveridad CodSeveridadNavigation { get; set; }
    }
}
