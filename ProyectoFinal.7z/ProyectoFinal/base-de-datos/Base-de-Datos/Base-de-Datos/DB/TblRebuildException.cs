﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildException
    {
        public int IdReorgException { get; set; }
        public string Schemaname { get; set; }
        public string Tablename { get; set; }
        public string TipoTarea { get; set; }
        public string AccionRealizar { get; set; }
    }
}
