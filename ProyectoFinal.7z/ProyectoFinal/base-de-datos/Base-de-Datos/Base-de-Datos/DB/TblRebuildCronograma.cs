﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildCronograma
    {
        public int IdReorgCronograma { get; set; }
        public string Groupname { get; set; }
        public string Endday { get; set; }
        public string Endhour { get; set; }
        public int? Paralelismo { get; set; }
        public bool? IsEnabled { get; set; }
    }
}
