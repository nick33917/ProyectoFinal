﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblAcuerdos
    {
        public int CodAcuerdo { get; set; }
        public int CodUsuarioresponsable { get; set; }
        public string NombreAcuerdo { get; set; }
        public int? Evolutivo { get; set; }
        public string NombreAcuerdoCorto { get; set; }
        public string Tipo { get; set; }

        public virtual TblGruposAcuerdos TblGruposAcuerdos { get; set; }
    }
}
