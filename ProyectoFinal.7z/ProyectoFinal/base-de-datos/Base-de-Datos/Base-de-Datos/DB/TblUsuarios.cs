﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblUsuarios
    {
        public TblUsuarios()
        {
            TblEvaluacion = new HashSet<TblEvaluacion>();
            TblPuesto = new HashSet<TblPuesto>();
            TblUsuariosMail = new HashSet<TblUsuariosMail>();
            TblUsuariosTelefono = new HashSet<TblUsuariosTelefono>();
        }

        public int CodUsuario { get; set; }
        public int? CodCategoria { get; set; }
        public int? CodAcuerdoOriginal { get; set; }
        public string NombreUsuario { get; set; }
        public string Apellidousuario { get; set; }
        public string Legajo { get; set; }
        public int? NumEmpleado { get; set; }
        public int? Estado { get; set; }
        public int? CodSupervisor { get; set; }
        public string Foto { get; set; }
        public DateTime? FechaNacimiento { get; set; }
        public int? CodCompany { get; set; }
        public int? CodObs { get; set; }
        public int? CodEspecialista { get; set; }
        public int? CodGerente { get; set; }
        public int? CodPerfil { get; set; }
        public DateTime? RequestDate { get; set; }
        public DateTime? PlannedStart { get; set; }
        public DateTime? ActualStart { get; set; }
        public DateTime? PlannedEnd { get; set; }
        public DateTime? ActualEnd { get; set; }
        public string Observaciones { get; set; }
        public decimal? Galar { get; set; }
        public string NroEmpleadoAcc { get; set; }
        public string EnterpriseIdacc { get; set; }
        public string SerialNumberNotebook { get; set; }
        public int? CodSkill { get; set; }
        public DateTime? IngresoAccenture { get; set; }

        public virtual TblCategorias CodCategoriaNavigation { get; set; }
        public virtual ICollection<TblEvaluacion> TblEvaluacion { get; set; }
        public virtual ICollection<TblPuesto> TblPuesto { get; set; }
        public virtual ICollection<TblUsuariosMail> TblUsuariosMail { get; set; }
        public virtual ICollection<TblUsuariosTelefono> TblUsuariosTelefono { get; set; }
    }
}
