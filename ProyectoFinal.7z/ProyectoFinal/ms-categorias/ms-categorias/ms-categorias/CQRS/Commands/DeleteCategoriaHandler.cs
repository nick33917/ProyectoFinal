﻿using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_categorias.CQRS.Commands
{
    public class DeleteCategoriaHandler : IRequestHandler<DeleteCategoriaQuery, bool>
    {
        public readonly RRHHContext _db;

        public DeleteCategoriaHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeleteCategoriaQuery request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var result = _db.TblCategorias.FirstOrDefault(c => c.CodCategoria == request.CodCategoria);
                _db.TblCategorias.Remove(result);
                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch
            {
              
            }
            return rtn;
        }
    }
}
