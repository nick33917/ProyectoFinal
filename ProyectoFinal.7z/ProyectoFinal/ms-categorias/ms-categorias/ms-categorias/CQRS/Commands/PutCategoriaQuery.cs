﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_categorias.CQRS.Commands
{
    public class PutCategoriaQuery
    {
    }
}
