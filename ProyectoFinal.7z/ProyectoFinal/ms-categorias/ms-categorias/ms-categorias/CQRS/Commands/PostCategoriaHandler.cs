﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_categorias.CQRS.Commands
{
    public class PostCategoriaHandler : IRequestHandler<PostCategoriaQuery, bool>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostCategoriaHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PostCategoriaQuery request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            TblCategorias categoria = new TblCategorias
            {
                CodCategoria = request.UnCategoria.CodCategoria,
                NombreCategoria = request.UnCategoria.NombreCategoria,
                Level = request.UnCategoria.Level,
                Skill = request.UnCategoria.Skill
            };

            try
            {
                await _db.TblCategorias.AddAsync(categoria);
                await _db.SaveChangesAsync();
                rtn = true;


            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return rtn;
        }
    }
}
