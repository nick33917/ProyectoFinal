﻿using MediatR;
using ms_categorias.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_categorias.CQRS.Commands
{
    public class PostCategoriaQuery : IRequest<bool>
    {
        public Categoria UnCategoria { get; set; }
    }
}
