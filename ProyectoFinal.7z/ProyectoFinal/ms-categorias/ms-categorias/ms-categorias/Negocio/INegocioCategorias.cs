﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_categorias.Modelo;

namespace ms_categorias.Negocio
{
    public interface INegocioCategorias
    {
        Task<List<Categoria>> GetCategorias();
        Task<Categoria> GetCategoria(int codCategoria);
        Task<bool> CrearCategoria(Categoria categoria);
        Task<bool> BorrarCategoria(int codCategoria);
        void ModificarCategoria(int codCategoria, Categoria categoria);
    }
}
